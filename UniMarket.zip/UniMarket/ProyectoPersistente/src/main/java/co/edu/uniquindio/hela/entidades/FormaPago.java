package co.edu.uniquindio.hela.entidades;
/**
 * @author Mateo Henao R,AnaMaria
 * Enum implementado para las formas de pago que puede tener alguna compra
 * @version 1.0
 */

public enum FormaPago {
	efectivo,tarjeta,paypal,bitcoin
}
