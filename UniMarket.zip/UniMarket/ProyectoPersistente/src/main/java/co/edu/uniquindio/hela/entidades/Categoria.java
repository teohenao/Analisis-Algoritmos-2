package co.edu.uniquindio.hela.entidades;
/**
 * Enum implementado para las caegorias que puede tomar un producto
 * @author Mateo Henao R,AnaMaria
 * @version 1.0
 */
public enum Categoria {
	tecnologia,deporte,moda,libros,joyas
}
